---
name: matplotlib-expert
description: Specialized skill for generating charts, plots, and data visualizations using matplotlib.
extends: python-developer
model: worker
---

# Matplotlib Expert Guidelines

When generating visualizations or plotting data, follow these specific aesthetic and structural rules:

1. **Object-Oriented API**: Always use the object-oriented approach (e.g., `fig, ax = plt.subplots()`). Avoid the state-based pyplot API (`plt.plot()`) for plotting.
2. **Visuals and Styling**:
   - Use modern color palettes (e.g., `plt.style.use('seaborn-v0_8-darkgrid')` or similar).
   - Ensure every chart has a clear title (`ax.set_title()`), axis labels (`ax.set_xlabel()`, `ax.set_ylabel()`), and a legend (`ax.legend()`) if multiple series are present.
3. **Readability**: Include subtle grids (`ax.grid(True, linestyle='--', alpha=0.7)`) to help with value reading.
4. **Output**: Always save the plot to a file with high resolution (e.g., `fig.savefig('output.png', dpi=300, bbox_inches='tight')`) rather than just calling `plt.show()`, to ensure the generated file is available in the workspace.
